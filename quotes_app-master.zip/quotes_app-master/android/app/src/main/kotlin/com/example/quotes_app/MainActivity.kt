package com.example.quotes_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
