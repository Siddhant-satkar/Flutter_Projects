# quotes_app

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.

<p>
 <img src = "https://user-images.githubusercontent.com/113697861/219848715-8ecac032-1f7d-4f45-9acc-591a159134db.jpg" width=22% height=35%>
 <img src = "https://user-images.githubusercontent.com/113697861/219848728-c0ddce89-d208-4edb-bda4-cdafa59f0129.jpg" width=22% height=35%>
 <img src = "https://user-images.githubusercontent.com/113697861/219848703-8440867e-65a1-4a50-aab6-a4ad2a7f1582.jpg" width=22% height=35%>
 <img src = "https://user-images.githubusercontent.com/113697861/219848704-2718e86c-7652-4c8b-b38a-964e327ec469.jpg" width=22% height=35%>
 <img src = "https://user-images.githubusercontent.com/113697861/219848706-1109b1b6-6089-4d71-ba06-a85df6dce293.jpg" width=22% height=35%>
 <img src = "https://user-images.githubusercontent.com/113697861/219848709-d59c6f1f-adde-4969-8125-f88345a83fb0.jpg" width=22% height=35%>
 <img src = "https://user-images.githubusercontent.com/113697861/219848712-a24c7d53-972f-4c19-8ffa-d366590cec50.jpg" width=22% height=35%>
 
 # With Autorotation
 
https://user-images.githubusercontent.com/113697861/219848875-07a76652-f6b8-4e28-82c8-d8383a517b85.mp4

https://user-images.githubusercontent.com/113697861/219848877-bfc11bf4-dd4b-424d-a2c8-bf74a701264d.mp4


 
</p>



