package com.example.income_expense_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
