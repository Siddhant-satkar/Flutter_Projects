import 'package:get/get.dart';

class GraphController extends GetxController
{

}