# newpaper_app

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.


<p>
<img src = "https://user-images.githubusercontent.com/113697861/229365452-dd2c0e05-9851-4822-8702-175c9fbae086.png" width=22% height=35%>
<img src = "https://user-images.githubusercontent.com/113697861/229365462-e3f81471-02fd-48b6-a8ad-9cdc4e6390d0.png" width=22% height=35%>
<img src = "https://user-images.githubusercontent.com/113697861/229365467-2c2db50d-ebb7-419c-b221-64d0def962fd.png" width=22% height=35%>
<img src = "https://user-images.githubusercontent.com/113697861/229365474-81013c7e-47f1-4cff-9c30-73e62a4da670.png" width=22% height=35%>
<img src = "https://user-images.githubusercontent.com/113697861/229365482-0ac720fc-f9d5-47a0-985b-21e7e7dd605b.png" width=22% height=35%>

</p>

