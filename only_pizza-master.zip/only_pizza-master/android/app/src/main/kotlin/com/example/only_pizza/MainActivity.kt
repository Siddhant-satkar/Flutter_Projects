package com.example.only_pizza

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
