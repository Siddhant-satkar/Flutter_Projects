import 'package:flutter/material.dart';

class Homeprovider extends ChangeNotifier
{
  List logoImgList = [
    "assets/logo/dom.png",
    "assets/logo/lap.png",
    "assets/logo/mart.png",
    "assets/logo/hut.png",
    "assets/logo/oven.png",
    "assets/logo/laziz.png",
    "assets/logo/exp.png",
    "assets/logo/insta.png",
  ];

  List pizzaName = [
    "Domino's Pizza",
    "La'pinos Pizza",
    "Martinos Pizza",
    "Pizza Hut",
    "Oven Story",
    "Laziz Pizza",
    "Pizza Express",
    "Insta Pizza",
  ];


}