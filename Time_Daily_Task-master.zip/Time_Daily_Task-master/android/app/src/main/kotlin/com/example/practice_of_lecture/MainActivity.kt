package com.example.practice_of_lecture

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
